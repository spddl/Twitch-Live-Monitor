# Twitch Live Monitor

### Install

- [Download in Chrome Web Store](https://chrome.google.com/webstore/detail/twitch-live-monitor/geckecbipnimmcefppeckcggceikjmjj)
- [Download in Firefox Add-ons](https://addons.mozilla.org/de/firefox/addon/twitch-live-monitor/)

Boilerplate from https://github.com/lxieyang/chrome-extension-boilerplate-react
