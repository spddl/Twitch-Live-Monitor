import React from 'react'
import { render } from 'react-dom'

import Options from './Options'
import './index.css'

render(<Options />, window.document.querySelector('#app-container'))
